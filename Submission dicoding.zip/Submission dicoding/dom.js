let nav = document.getElementById("navigation");
function onScroll() {
	if (this.pageYOffset >  nav.offsetTop) {
		nav.classList.add("nav-fixed-top");
	}else{
		nav.classList.remove("nav-fixed-top");
	}
}
